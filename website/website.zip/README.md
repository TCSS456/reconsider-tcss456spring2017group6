# RealtimePythonChat
Sample chat written by Python using Flask and Socket.io

Based on tutorial of Hüseyin Babal
https://code.tutsplus.com/tutorials/build-a-real-time-chat-application-with-modulus-and-python--cms-24462

![Login image](https://raw.githubusercontent.com/quangtqag/RealtimePythonChat/master/galery/ss1.png "")
![Chat image](https://raw.githubusercontent.com/quangtqag/RealtimePythonChat/master/galery/ss2.png "")

Pull it and run: 
* `source venv/bin/activate`
* `pip install -r requirements.txt --user`
* `python server.py`
